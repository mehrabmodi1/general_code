%clear a:
%{
B56 Training flies via PAM alpha1 and expressing dopamine sensor in kenyon
cells.

Matlab script to program an arduino controlling valves on an odor delivery system.
The arduino must be programmed with  Odor_Deliver3.ino.
The other adurino controls LED red light stimulation via DMD
LED_Deliver3.ino.
Step summary
1. setup serial communication with arduino
2. send odor protocol
3. confirm odor protocol has been properly recieved
4. trigger odor delivery and scanimage imaging
5. place arduino back in mode to receive protocol
6. close serial communication to arduino
%}
working_directory = 'E:\DanBushey\20210520'
beampower = 20
parameters.scanZoomFactor = 3
parameters.numSlices = 1
parameters.stackZStepSize = 0
hSI.hConfigurationSaver.cfgLoadConfig('E:\Dan_Config\Config_Volume3.cfg');

logFile.Stem = hSI.hScan2D.logFileStem;
logFile.Directory =  hSI.hScan2D.logFilePath;
logFile.Counts = hSI.hScan2D.logFileCounter
directory = [working_directory, '\', logFile.Stem,  num2str(logFile.Counts,'%03.f')]
mkdir(directory)
hSI.hScan2D.logFilePath = directory
%Start recording sensor data from daq in separate process


% Setup serial communication with arduino for odor control
ser=serial('COM4','BaudRate', 9600);
fopen(ser);

% Setup serial communication with arduino for LED control
ser2=serial('COM7','BaudRate', 9600);
fopen(ser2);
pause(3)

%setting up communication to sensors
s = daq.createSession('ni');
%devices = daq.getDevices
ch = addAnalogInputChannel(s,'Dev4', [0, 1, 2,3,5,6,7], 'Voltage');
ch2 = addAnalogInputChannel(s,'Dev5', [0,1,2], 'Voltage');
%dig = addDigitalChannel(s, 'Dev4', 'Port0/Line0:5', 'InputOnly')

acq_rate = 1000;        %Hz
s.Rate = acq_rate;

ch(1).TerminalConfig = 'SingleEnded';
ch(1).Range = [-5, 5]
ch(2).TerminalConfig = 'SingleEnded';
ch(2).Range = [-5, 5]
ch(3).TerminalConfig = 'SingleEnded';
ch(3).Range = [-5, 5]
ch(4).TerminalConfig = 'SingleEnded';
ch(4).Range = [-5, 5]
ch(5).TerminalConfig = 'SingleEnded'; %getting stop signal
ch(5).Range = [-5, 5]
ch(6).TerminalConfig = 'SingleEnded';
ch(6).Range = [-5, 5]
ch(5).TerminalConfig = 'SingleEnded';
ch(5).Range = [-5, 5]
ch(7).TerminalConfig = 'SingleEnded';
ch(7).Range = [-5, 5]

ch2(1).TerminalConfig = 'SingleEnded';
ch2(1).Range = [-5, 5]
ch2(2).TerminalConfig = 'SingleEnded';
ch2(2).Range = [-5, 5]
ch2(3).TerminalConfig = 'SingleEnded';
ch2(3).Range = [-5, 5]
acq_rate = 1000;        %Hz
s.Rate = acq_rate;

%{ 
2. Send arduino the odor protocol
Communications to arduino
The first communication sends the '<' array length (n) followed by # char (<n#). This
triggers receiving on arduino end.
The pins and time array have to be the same length.
The pin indicates the valve while the time indicates length in ms for the
period.


Two arrays are being sent. One array contains the pins. A pin=0 means that all valves are closed except the pass through chamber
(pin=9, board=5). The second array contains the time in ms. Both arrays must be the same length.
%}

%scope settings
hSI.hRoiManager.scanZoomFactor = parameters.scanZoomFactor ;
hSI.hStackManager.numSlices = parameters.numSlices;
hSI.hStackManager.stackZStepSize = parameters.stackZStepSize; %in microns
hSI.hScan2D.logFramesPerFile = 'Inf' %parameters.numSlices;
hSI.hFastZ.numVolumes=10000
hSI.hBeams.powers = [beampower 0];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Pre-testing

%PROGRAMMING odor delivery
%7==MCH
%5==OCT
trials = 10;
odor_order = zeros(trials,1);
for i =1:trials;
    if mod(i,2)==0; %test if number is even
        odor_order(i) = 5;
    else;
        odor_order(i) = 7;
    end;
end;



for codor = 1: length(odor_order);
    %sending odor delivery protocol to arduino
    pins = [0,    odor_order(codor),      0]
    time = [20000, 10000,30000];
    array_len = ['<' num2str(length(time)) '#']
    fwrite(ser, array_len, 'char');
    for i = 1:length(pins)
        fwrite(ser, strcat(num2str(pins(i)), ','), 'char');
    end
    pins_out = zeros(length(pins),1)
    for i = 1:length(pins)
        pins_out(i) =str2num(fscanf(ser))
    end

    for i = 1:length(time)
        fwrite(ser, strcat(num2str(time(i)), ','), 'char');
    end
    time_out = zeros(length(time),1)
    for i = 1:length(time)
        time_out(i)=str2num(fscanf(ser))
    end
    
    %% changing file name
    file_affix = ['_TimeSeries_PreTesting-', sprintf('%04d', int16(codor)), '_Odor-', sprintf('%02d', int16(odor_order(codor)))]
    hSI.hScan2D.logFileStem = [logFile.Stem, file_affix];
    cdirectory = [directory, '\PreTesting-', sprintf('%04d', int16(codor))]
    mkdir(cdirectory)
    hSI.hScan2D.logFilePath = cdirectory
    
    %start sensor recording8
    tot_tr_dur = sum(time) /1000 + 1
    s.DurationInSeconds = tot_tr_dur; %add 4 s as a fudge factor
    s.NotifyWhenDataAvailableExceeds = acq_rate.*tot_tr_dur;
    sensor_output = [cdirectory,'\', logFile.Stem, file_affix, '_Sensor.mat']
    lh = addlistener(s,'DataAvailable',  @(src,evt)aq_data_bk3(src, evt, sensor_output));
  
    %PROGRAMMING LED delivery
    LED_Voltage = [0]
    LED_time = [sum(time),];
    array_len = ['<' num2str(length(LED_time)) '#']
    fwrite(ser2, array_len, 'char');
    for i = 1:length(LED_Voltage)
        fwrite(ser2, strcat(num2str(LED_Voltage(i)), ','), 'char');
    end
    LED_Voltage_out = zeros(length(LED_Voltage),1)
    for i = 1:length(LED_Voltage)
        pins_out(i) =str2num(fscanf(ser2))
    end
    for i = 1:length(LED_time)
        fwrite(ser2, strcat(num2str(LED_time(i)), ','), 'char');
    end
    time_out = zeros(length(LED_time),1)
    for i = 1:length(LED_time)
        time_out(i)=str2num(fscanf(ser2))
    end

    %4. Triggering the odor delivery
    start =1
    s.startBackground();  
    fwrite(ser2,  num2str(start), 'char');
    fwrite(ser,  num2str(start), 'char');
    
    hSI.startGrab;
    while hSI.active
        pause(10)
    end
  

    %5. Place arduino back into mode to receive odor protocol
    a = '>'
    fwrite(ser, a, 'char');
    fwrite(ser2, a, 'char');
    delete(lh)
    pause(1)  %should be 30s?????
end
pause(60)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Training
pins = [0,    7,     0]
time = [20000, 60000, 40000 ];
array_len = ['<' num2str(length(time)) '#']
fwrite(ser, array_len, 'char');

for i = 1:length(pins)
    fwrite(ser, strcat(num2str(pins(i)), ','), 'char');
end
pins_out = zeros(length(pins),1)
for i = 1:length(pins)
    pins_out(i) =str2num(fscanf(ser))
end

for i = 1:length(time)
    fwrite(ser, strcat(num2str(time(i)), ','), 'char');
end
time_out = zeros(length(time),1)
for i = 1:length(time)
    time_out(i)=str2num(fscanf(ser))
end

%PROGRAMMING LED delivery
LED_Voltage = [0] %(0-1023)
LED_time = [time(1)+10000+1800]; %odor starts 10s + time for odoer to reach animal
for i = 1:30;
    LED_Voltage(end+1) = 300
    LED_time(end+1) =1000
    LED_Voltage(end+1) = 0
    LED_time(end+1) =1000
end
LEDDD = [LED_Voltage; LED_time]
LED_Voltage(end+1) = 0
LED_time(end+1) =sum(time) - sum(LED_time)
array_len = ['<' num2str(length(LED_time)) '#']

fwrite(ser2, array_len, 'char');
for i = 1:length(LED_Voltage)
    fwrite(ser2, strcat(num2str(LED_Voltage(i)), ','), 'char');
end
LED_Voltage_out = zeros(length(LED_Voltage),1)
for i = 1:length(LED_Voltage)
    pins_out(i) =str2num(fscanf(ser2))
end
for i = 1:length(LED_time)
    fwrite(ser2, strcat(num2str(LED_time(i)), ','), 'char');
end
time_out = zeros(length(LED_time),1)
for i = 1:length(LED_time)
    time_out(i)=str2num(fscanf(ser2))
end
time_wait = 51 %51
for i =1:3; %3
    file_affix = ['_TimeSeries_Training-', sprintf('%04d', int16(i)), '_Odor-', sprintf('%02d', int16(7))];
    hSI.hScan2D.logFileStem = [logFile.Stem, file_affix];
    cdirectory = [directory, '\Training-', sprintf('%04d', int16(i))]
    mkdir(cdirectory)
    hSI.hScan2D.logFilePath = cdirectory
    %start sensor recording
    sensor_output = [cdirectory,'\', logFile.Stem, file_affix, '_Sensor.mat']
    tot_tr_dur = sum(time) /1000 + 7 %add 7 s as a fudge factor
    pause(time_wait);
    s.DurationInSeconds = tot_tr_dur;
    lh = addlistener(s,'DataAvailable',  @(src,evt)aq_data_bk3(src, evt, sensor_output));
    s.NotifyWhenDataAvailableExceeds = acq_rate.*tot_tr_dur;
    pause(3)
    s.startBackground();
    pause(1)
    start =1
    fwrite(ser2,  num2str(start), 'char');
    fwrite(ser,  num2str(start), 'char');
    hSI.startGrab;
    while hSI.active
        pause(10)
    end
    delete(lh)
end
a = '>'
fwrite(ser, a, 'char');
fwrite(ser2, a, 'char');
pause(120)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Post-Testing
for codor = 1: length(odor_order);
    %sending odor delivery protocol to arduino
    pins = [0,    odor_order(codor),      0]
    time = [20000, 10000,30000];
    array_len = ['<' num2str(length(time)) '#']
    fwrite(ser, array_len, 'char');
    for i = 1:length(pins)
        fwrite(ser, strcat(num2str(pins(i)), ','), 'char');
    end
    pins_out = zeros(length(pins),1)
    for i = 1:length(pins)
        pins_out(i) =str2num(fscanf(ser))
    end

    for i = 1:length(time)
        fwrite(ser, strcat(num2str(time(i)), ','), 'char');
    end
    time_out = zeros(length(time),1)
    for i = 1:length(time)
        time_out(i)=str2num(fscanf(ser))
    end
    
    %% changing file name
    file_affix = ['_TimeSeries_PostTesting-', sprintf('%04d', int16(codor)), '_Odor-', sprintf('%02d', int16(odor_order(codor)))]
    hSI.hScan2D.logFileStem = [logFile.Stem, file_affix];
    cdirectory = [directory, '\PostTesting-', sprintf('%04d', int16(codor))]
    mkdir(cdirectory)
    hSI.hScan2D.logFilePath = cdirectory
    
    %start sensor recording8
    tot_tr_dur = sum(time) /1000 + 1
    s.DurationInSeconds = tot_tr_dur; %add 4 s as a fudge factor
    s.NotifyWhenDataAvailableExceeds = acq_rate.*tot_tr_dur;
    sensor_output = [cdirectory,'\', logFile.Stem, file_affix, '_Sensor.mat']
    lh = addlistener(s,'DataAvailable',  @(src,evt)aq_data_bk3(src, evt, sensor_output));
    
    %PROGRAMMING LED delivery
    LED_Voltage = [0]
    LED_time = [sum(time),];
    array_len = ['<' num2str(length(LED_time)) '#']
    fwrite(ser2, array_len, 'char');
    for i = 1:length(LED_Voltage)
        fwrite(ser2, strcat(num2str(LED_Voltage(i)), ','), 'char');
    end
    LED_Voltage_out = zeros(length(LED_Voltage),1)
    for i = 1:length(LED_Voltage)
        pins_out(i) =str2num(fscanf(ser2))
    end
    for i = 1:length(LED_time)
        fwrite(ser2, strcat(num2str(LED_time(i)), ','), 'char');
    end
    time_out = zeros(length(LED_time),1)
    for i = 1:length(LED_time)
        time_out(i)=str2num(fscanf(ser2))
    end

    %4. Triggering the odor delivery
    start =1
    s.startBackground();  
    fwrite(ser2,  num2str(start), 'char');
    fwrite(ser,  num2str(start), 'char');
    
    hSI.startGrab;
    while hSI.active
        pause(10)
    end
  

    %5. Place arduino back into mode to receive odor protocol
    a = '>'
    fwrite(ser, a, 'char');
    fwrite(ser2, a, 'char');
    delete(lh)
    pause(30)
end
hSI.hScan2D.logFileStem = logFile.Stem;
fclose(ser)
fclose(ser2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Take high intensity image for rois
file_affix = ['_HIimage']
hSI.hScan2D.logFileStem = [logFile.Stem, file_affix];
cdirectory = [directory, '\HIimage']
mkdir(cdirectory)

    
hSI.hConfigurationSaver.cfgLoadConfig('E:\Dan_Config\Config_Volume2.cfg');
hSI.hScan2D.logFilePath = cdirectory
hSI.hRoiManager.scanZoomFactor = parameters.scanZoomFactor ;
hSI.hStackManager.numSlices = parameters.numSlices;
hSI.hStackManager.stackZStepSize = parameters.stackZStepSize; %in microns
hSI.hScan2D.logFramesPerFile = parameters.numSlices;
hSI.hFastZ.numVolumes=20
hSI.hBeams.powers = [80 0];
hSI.startGrab;
while hSI.active
    pause(10)
end

hSI.hBeams.powers = [15 0];
disp('Finished')
