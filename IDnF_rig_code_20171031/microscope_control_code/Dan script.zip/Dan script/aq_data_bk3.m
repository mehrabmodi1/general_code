function data = aq_data_bk(src, event, file)
%This function is called by the listener in the background acquisition to
%acquire the PID signal and write it to file.
sensor.MiCEbay = event.Data(:, 8);
sensor.PID = event.Data(:, 1);
sensor.time = event.TimeStamps
sensor.trigger = event.Data(:, 9);
sensor.valve1 = event.Data(:,5);
sensor.valve2 = event.Data(:,6);
sensor.valve3 = event.Data(:,4);
sensor.valve4 = event.Data(:,7);
sensor.valve5 = event.Data(:,3);
sensor.LED1 = event.Data(:, 10);


save(file, 'sensor');
