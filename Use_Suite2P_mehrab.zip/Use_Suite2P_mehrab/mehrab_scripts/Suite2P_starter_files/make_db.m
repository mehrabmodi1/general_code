i = 0;

i = 1;
db(i).mouse_name    = '20170313';
db(i).date          = '2015-04-27';
db(i).expts         = ['MB149BX20xsytGC6f - Copy' 'odor_trials'];
db(i).nchannels     = 1;